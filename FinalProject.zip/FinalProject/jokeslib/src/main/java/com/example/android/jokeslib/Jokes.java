package com.example.android.jokeslib;

public class Jokes {

    static String joke = "funny joke goes here";

    public static String getJoke() {
        return joke;
    }
}
